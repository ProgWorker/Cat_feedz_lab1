package com.example.myapplication;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public static final String SOCIAL_NETWORK_TAG = "SocialIntegrationMain.SOCIAL_NETWORK_TAG";
    public final String VK_KEY = getResources().getText(R.string.vk_app_id).toString();
    Button a1;
    TextView t1;
    ImageView imga;
    int counter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);
        a1 = findViewById(R.id.a1);
        t1 = findViewById(R.id.textView);
        t1.setText(VK_KEY);
        imga = findViewById(R.id.imga);
        a1.setOnClickListener(view -> {
            counter++;
            if (counter==15){
                counter = 0;
                Animation anim;
                anim = AnimationUtils.loadAnimation (getApplicationContext(), R.anim.joy);
                imga.startAnimation(anim);
            }
            String satmas [] =  t1.getText().toString().split(": ");
            if(!isNumeric(satmas[satmas.length-1])){
                t1.setText("Satiety: 1");
            } else {
                t1.setText("Satiety: " + (Integer.parseInt(t1.getText().toString().split(": ")[1])+1));
            }

        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Fragment fragment = getSupportFragmentManager().findFragmentByTag(SOCIAL_NETWORK_TAG);
        if (fragment != null) {
            fragment.onActivityResult(requestCode, resultCode, data);
        }
    }

    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            double d = Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }
}

